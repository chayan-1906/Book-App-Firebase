package com.example.bookapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bookapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    // view binding
    private ActivityMainBinding activityMainBinding;

    private ImageView imageViewIcon;
    private Button btnLogin;
    private Button btnSkipLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        activityMainBinding = ActivityMainBinding.inflate ( getLayoutInflater ( ) );
        setContentView ( activityMainBinding.getRoot ( ) );

        // handle loginBtn click, start login screen
        activityMainBinding.btnLogin.setOnClickListener ( v -> startActivity ( new Intent ( MainActivity.this, LoginActivity.class ) ) );

        // handle skipBtn click, start continue without login screen
        activityMainBinding.btnSkipLogin.setOnClickListener ( v -> startActivity ( new Intent ( MainActivity.this, DashboardUserActivity.class ) ) );
    }
}
