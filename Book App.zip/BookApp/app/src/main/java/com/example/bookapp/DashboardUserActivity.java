package com.example.bookapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bookapp.databinding.ActivityDashboardUserBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DashboardUserActivity extends AppCompatActivity {

    // view binding
    private ActivityDashboardUserBinding activityDashboardUserBinding;

    // Firebase
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;

    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        activityDashboardUserBinding = ActivityDashboardUserBinding.inflate ( getLayoutInflater ( ) );
        setContentView ( activityDashboardUserBinding.getRoot ( ) );

        // Firebase
        firebaseAuth = FirebaseAuth.getInstance ( );
        checkUser ( );

        // handle click, logout
        activityDashboardUserBinding.imageViewLogout.setOnClickListener ( v -> {
            // logout user
            firebaseAuth.signOut ( );
            checkUser ( );
        } );
    }

    private void checkUser() {
        // get current user
        firebaseUser = firebaseAuth.getCurrentUser ( );
        if (firebaseUser == null) {
            // user not logged in
            // start main screen
            startActivity ( new Intent ( DashboardUserActivity.this, MainActivity.class ) );
            finish ( );
        } else {
            // user logged in, get user info
            email = firebaseUser.getEmail ( );
            activityDashboardUserBinding.textViewSubtitleDashboardAdmin.setText ( email );
        }
    }
}