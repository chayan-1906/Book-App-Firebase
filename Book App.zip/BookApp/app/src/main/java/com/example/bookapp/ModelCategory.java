package com.example.bookapp;

public class ModelCategory {

    String id;
    String uid;
    String category;
    long timestamp;

    // constructor for firebase
    public ModelCategory() { }

    // parameterized constructor
    public ModelCategory(String id, String uid, String category, long timestamp) {
        this.id = id;
        this.uid = uid;
        this.category = category;
        this.timestamp = timestamp;
    }

    /* Getter/Setter */
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
