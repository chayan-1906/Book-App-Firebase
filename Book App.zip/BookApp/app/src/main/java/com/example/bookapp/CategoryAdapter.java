package com.example.bookapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookapp.databinding.RowCategoryBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shashank.sony.fancytoastlib.FancyToast;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> implements Filterable {

    private static final String TAG = "CategoryAdapter";

    // view binding
    @SuppressLint("StaticFieldLeak")
    static RowCategoryBinding rowCategoryBinding;

    @SuppressLint("StaticFieldLeak")
    private static Context context;
    public static ArrayList<ModelCategory> modelCategoryArrayList = null;
    public static ArrayList<ModelCategory> filterList = null;

    // instance of filter class
    private FilterCategory filterCategory;

    // firebase
    private DatabaseReference databaseReferenceCategories;

    public CategoryAdapter(Context context, ArrayList<ModelCategory> modelCategoryArrayList) {
        CategoryAdapter.context = context;
        CategoryAdapter.modelCategoryArrayList = modelCategoryArrayList;
        CategoryAdapter.filterList = modelCategoryArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // bind row_category.xml
        rowCategoryBinding = RowCategoryBinding.inflate ( LayoutInflater.from ( context ), parent, false );
        return new ViewHolder ( rowCategoryBinding.getRoot ( ) );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // get data
        ModelCategory modelCategory = modelCategoryArrayList.get ( position );
        String id = modelCategory.getId ( );
        String uid = modelCategory.getUid ( );
        String category = modelCategory.getCategory ( );
        long timestamp = modelCategory.getTimestamp ( );

        // set data
        holder.textViewCategoryTitle.setText ( category );

        // handle click, delete category
        holder.imageButtonDelete.setOnClickListener ( v -> {
            // confirm delete dialog
            String categoryToBeDeleted = holder.textViewCategoryTitle.getText ( ).toString ( );
            AlertDialog.Builder builder = new AlertDialog.Builder ( context );
            builder.setTitle ( "Delete " + categoryToBeDeleted );
            builder.setMessage ( "Do you want to delete " + categoryToBeDeleted + " category?" );
            builder.setPositiveButton ( "Delete", (dialog, which) -> {
                // begin delete
                deleteCategory ( modelCategory, holder );
            } );
            builder.setNeutralButton ( "No", (dialog, which) -> dialog.dismiss ( ) );
            builder.show ( );
//            FancyToast.makeText ( context, category + " deleted successfully", FancyToast.LENGTH_SHORT, FancyToast.SUCCESS, false ).show ( );
        } );
    }

    private void deleteCategory(ModelCategory modelCategory, ViewHolder holder) {
        // get id of category to be deleted
        String id = modelCategory.getId ( );
        // Database Root -> Categories -> categoryId
        databaseReferenceCategories = FirebaseDatabase.getInstance ( ).getReference ( "Categories" );
        databaseReferenceCategories.child ( id ).removeValue ( ).addOnSuccessListener ( unused -> FancyToast.makeText ( context, modelCategory.getCategory ( ) + " deleted successfully", FancyToast.LENGTH_SHORT, FancyToast.SUCCESS, false ).show ( ) ).addOnFailureListener ( e -> FancyToast.makeText ( context, e.getMessage ( ), FancyToast.LENGTH_SHORT, FancyToast.ERROR, false ).show ( ) );
    }

    @Override
    public int getItemCount() {
        return modelCategoryArrayList.size ( );
    }

    @Override
    public Filter getFilter() {
        if (filterCategory == null) {
            filterCategory = new FilterCategory ( filterList, this );
        }
        return filterCategory;
    }

    /* View holder class to hold UI for row_category.xml */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        // ui views of row_category
        private final TextView textViewCategoryTitle;
        private final ImageButton imageButtonDelete;

        public ViewHolder(@NonNull View itemView) {
            super ( itemView );

            textViewCategoryTitle = rowCategoryBinding.textViewCategoryTitle;
            imageButtonDelete = rowCategoryBinding.imageButtonDelete;
        }
    }
}
