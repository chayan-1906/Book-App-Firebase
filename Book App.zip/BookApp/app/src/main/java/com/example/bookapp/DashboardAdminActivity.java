package com.example.bookapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bookapp.databinding.ActivityDashboardAdminBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DashboardAdminActivity extends AppCompatActivity {

    // view binding
    private ActivityDashboardAdminBinding activityDashboardAdminBinding;

    // Firebase
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReferenceCategories;

    private String email;

    // arraylist to store categories
    private ArrayList<ModelCategory> modelCategoryArrayList;
    // adapter
    private CategoryAdapter categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        activityDashboardAdminBinding = ActivityDashboardAdminBinding.inflate ( getLayoutInflater ( ) );
        setContentView ( activityDashboardAdminBinding.getRoot ( ) );

        // Firebase
        firebaseAuth = FirebaseAuth.getInstance ( );
        databaseReferenceCategories = FirebaseDatabase.getInstance ( ).getReference ( "Categories" );
        checkUser ( );
        loadCategories ( );

        // edit text change listener, search
        activityDashboardAdminBinding.textInputEditTextSearch.addTextChangedListener ( new TextWatcher ( ) {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // called as and when type each letter
                try {
                    categoryAdapter.getFilter ( ).filter ( s );
                } catch (Exception e) {
                    e.printStackTrace ( );
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        } );

        // handle click, logout
        activityDashboardAdminBinding.imageViewLogout.setOnClickListener ( v -> {
            // logout user
            firebaseAuth.signOut ( );
        } );

        // handle click, start add category screen
        activityDashboardAdminBinding.btnAddCategory.setOnClickListener ( v -> startActivity ( new Intent ( DashboardAdminActivity.this, CategoryAddActivity.class ) ) );

        // handle click, start add category screen
        activityDashboardAdminBinding.floatingActionButtonAddPdf.setOnClickListener ( v -> startActivity ( new Intent ( DashboardAdminActivity.this, AddPdfActivity.class ) ) );
    }

    private void loadCategories() {
        // init arraylist
        modelCategoryArrayList = new ArrayList<> ( );
        // get all categories
        databaseReferenceCategories.addValueEventListener ( new ValueEventListener ( ) {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // make arraylist clear, before adding data
                modelCategoryArrayList.clear ( );
                for (DataSnapshot dataSnapshot : snapshot.getChildren ( )) {
                    // get data
                    ModelCategory modelCategory = dataSnapshot.getValue ( ModelCategory.class );
                    // add to arraylist
                    modelCategoryArrayList.add ( modelCategory );
                }
                // setup adapter
                categoryAdapter = new CategoryAdapter ( DashboardAdminActivity.this, modelCategoryArrayList );
                //set adapter to recyclerView
                activityDashboardAdminBinding.recyclerViewCategories.setAdapter ( categoryAdapter );
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        } );
    }

    private void checkUser() {
        // get current user
        firebaseUser = firebaseAuth.getCurrentUser ( );
        if (firebaseUser == null) {
            // user not logged in
            // start main screen
            startActivity ( new Intent ( DashboardAdminActivity.this, MainActivity.class ) );
            finish ( );
        } else {
            // user logged in, get user info
            email = firebaseUser.getEmail ( );
            //set in textview of toolbar
            activityDashboardAdminBinding.textViewSubtitleDashboardAdmin.setText ( email );
        }
    }
}
